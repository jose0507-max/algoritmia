Algoritmo ConversionMinutosHoras
    Definir minutosTotales, horas, minutosRestantes Como Entero

    Escribir "Ingrese la cantidad total de minutos:"
    Leer minutosTotales

    horas <- Trunc(minutosTotales / 60)
    minutosRestantes <- minutosTotales MOD 60

    Escribir minutosTotales, " minutos equivalen a ", horas, " hora(s) y ", minutosRestantes, " minuto(s)."
FinAlgoritmo
