Algoritmo CalculadoraCompra
    Definir precio, cantidad, subtotal, descuento, total Como Real

    Escribir "Ingrese el precio de cada producto:"
    Leer precio
    Escribir "Ingrese la cantidad de productos:"
    Leer cantidad

    subtotal <- precio * cantidad
    descuento <- subtotal * 0.10
    total <- subtotal - descuento

    Escribir "El subtotal es: ", subtotal
    Escribir "El descuento del 10% es: ", descuento
    Escribir "El total a pagar es: ", total
FinAlgoritmo
