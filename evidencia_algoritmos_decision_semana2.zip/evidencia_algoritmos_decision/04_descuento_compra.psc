Algoritmo DescuentoCompra
    Definir compra, descuento, total Como Real

    Escribir "Ingrese el valor de la compra:"
    Leer compra

    Si compra >= 100000 Entonces
        descuento <- compra * 0.10
    SiNo
        descuento <- 0
    FinSi

    total <- compra - descuento

    Escribir "El descuento aplicado es: ", descuento
    Escribir "El total a pagar es: ", total
FinAlgoritmo
