Algoritmo AprobacionAsignatura
    Definir nota Como Real

    Escribir "Ingrese la nota definitiva (0 a 5):"
    Leer nota

    Si nota >= 3.0 Entonces
        Escribir "La asignatura esta aprobada."
    SiNo
        Escribir "La asignatura no esta aprobada."
    FinSi
FinAlgoritmo
