// Ciclo REPETIR ... HASTA QUE: cuenta los digitos de un numero entero >= 0
Algoritmo ContarDigitos
	Definir n, cont Como Entero;
	cont <- 0;
	Escribir "Ingrese un numero entero (0 o mayor): " Sin Saltar;
	Leer n;
	Repetir
		n <- Trunc(n / 10);
		cont <- cont + 1;
	Hasta Que n = 0
	Escribir "El numero tiene ", cont, " digitos.";
FinAlgoritmo
