// Ciclo MIENTRAS: promedio de notas hasta que se ingrese -1 (centinela)
Algoritmo PromedioNotas
	Definir nota, suma, promedio Como Real;
	Definir cont Como Entero;
	suma <- 0;
	cont <- 0;
	Escribir "Ingrese una nota (-1 para terminar): " Sin Saltar;
	Leer nota;
	Mientras nota <> -1 Hacer
		suma <- suma + nota;
		cont <- cont + 1;
		Escribir "Ingrese una nota (-1 para terminar): " Sin Saltar;
		Leer nota;
	FinMientras
	Si cont > 0 Entonces
		promedio <- suma / cont;
		Escribir "Notas ingresadas: ", cont;
		Escribir "Promedio: ", promedio;
	SiNo
		Escribir "No se ingresaron notas.";
	FinSi
FinAlgoritmo
