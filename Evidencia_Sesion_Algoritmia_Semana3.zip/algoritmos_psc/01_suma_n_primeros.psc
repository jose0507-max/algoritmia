// Ciclo PARA: suma de los primeros N numeros naturales
Algoritmo SumaNPrimeros
	Definir n, i, suma Como Entero;
	suma <- 0;
	Escribir "Ingrese N (entero positivo): " Sin Saltar;
	Leer n;
	Para i <- 1 Hasta n Con Paso 1 Hacer
		suma <- suma + i;
	FinPara
	Escribir "La suma de los primeros ", n, " numeros es: ", suma;
FinAlgoritmo
