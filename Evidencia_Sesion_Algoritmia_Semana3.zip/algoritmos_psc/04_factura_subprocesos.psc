// Factura descompuesta en SubProcesos
// Proceso principal: Factura
// SubProcesos: LeerCantidad, LeerProductos, CalcularSubtotal,
//              CalcularDescuento, CalcularIVA, CalcularTotal, ImprimirFactura

// Ciclo REPETIR: valida que la cantidad de productos este entre 1 y 10
SubProceso n <- LeerCantidad()
	Definir n Como Entero;
	Repetir
		Escribir "Cuantos productos desea facturar? (1 a 10): " Sin Saltar;
		Leer n;
	Hasta Que n >= 1 Y n <= 10
FinSubProceso

// Ciclo PARA: lee nombre, cantidad y precio de cada producto
SubProceso LeerProductos(n, nombre, cant, precio)
	Definir i Como Entero;
	Para i <- 1 Hasta n Con Paso 1 Hacer
		Escribir "--- Producto ", i, " ---";
		Escribir "Nombre: " Sin Saltar;
		Leer nombre[i];
		Escribir "Cantidad: " Sin Saltar;
		Leer cant[i];
		Escribir "Precio unitario: " Sin Saltar;
		Leer precio[i];
	FinPara
FinSubProceso

// Ciclo PARA: acumula cantidad * precio de cada producto
SubProceso sub <- CalcularSubtotal(n, cant, precio)
	Definir i Como Entero;
	Definir sub Como Real;
	sub <- 0;
	Para i <- 1 Hasta n Con Paso 1 Hacer
		sub <- sub + cant[i] * precio[i];
	FinPara
FinSubProceso

// Descuento por volumen: 10% desde 500000, 5% desde 200000, 0% en otro caso
SubProceso desc <- CalcularDescuento(subtotal)
	Definir desc Como Real;
	Si subtotal >= 500000 Entonces
		desc <- subtotal * 0.10;
	SiNo
		Si subtotal >= 200000 Entonces
			desc <- subtotal * 0.05;
		SiNo
			desc <- 0;
		FinSi
	FinSi
FinSubProceso

// IVA del 19% sobre la base gravable
SubProceso iva <- CalcularIVA(base)
	Definir iva Como Real;
	iva <- base * 0.19;
FinSubProceso

SubProceso total <- CalcularTotal(base, iva)
	Definir total Como Real;
	total <- base + iva;
FinSubProceso

// Ciclo PARA: imprime el detalle y los totales
SubProceso ImprimirFactura(n, nombre, cant, precio, subtotal, desc, iva, total)
	Definir i Como Entero;
	Escribir "==================== FACTURA ====================";
	Escribir "Producto        Cant   P.Unit     Valor";
	Para i <- 1 Hasta n Con Paso 1 Hacer
		Escribir nombre[i], "   ", cant[i], "   ", precio[i], "   ", cant[i] * precio[i];
	FinPara
	Escribir "-------------------------------------------------";
	Escribir "Subtotal:        $", subtotal;
	Escribir "Descuento:       $", desc;
	Escribir "IVA (19%):       $", iva;
	Escribir "TOTAL A PAGAR:   $", total;
	Escribir "=================================================";
FinSubProceso

Algoritmo Factura
	Definir n Como Entero;
	Definir subtotal, descuento, base, iva, total Como Real;
	Definir nombre Como Caracter;
	Definir cant Como Entero;
	Definir precio Como Real;
	Dimension nombre[10], cant[10], precio[10];

	n <- LeerCantidad();
	LeerProductos(n, nombre, cant, precio);
	subtotal <- CalcularSubtotal(n, cant, precio);
	descuento <- CalcularDescuento(subtotal);
	base <- subtotal - descuento;
	iva <- CalcularIVA(base);
	total <- CalcularTotal(base, iva);
	ImprimirFactura(n, nombre, cant, precio, subtotal, descuento, iva, total);
FinAlgoritmo
